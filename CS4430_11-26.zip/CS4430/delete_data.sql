delete from roles;
delete from works;
delete from license;
delete from sw_usage;
delete from request;
delete from software;
delete from users;
delete from department;
