create database swlicensing;

use swlicensing;

create table users (
 userid varchar(10) primary key,
 pwd varchar(10) not null,
 fname varchar(20) not null,
 lname varchar(20) not null,
 login_time datetime
);

create table roles (
 userid varchar(10) primary key,
 role varchar(10) not null,
 foreign key(userid) references users(userid) 
);

create table department (
 name varchar(20) primary key,
 budget float
);

create table works (
 userid varchar(20) not null,
 depart_name varchar(20) not null,
 primary key(userid,depart_name),
 foreign key(userid) references users(userid),
 foreign key(depart_name) references department(name) 
);

create table software (
 sw_name varchar(20) primary key,
 fullpath varchar(120) not null
);


create table license (
 sw_name varchar(20) not null,
 depart_name varchar(20) not null,
 available int unsigned not null,
 cost_per_user float not null,
 primary key(sw_name,depart_name),
 foreign key(sw_name) references software(sw_name), 
 foreign key(depart_name) references department(name) 
);


create table sw_usage (
 sw_name varchar(20) not null,
 userid varchar(10) not null,
 start_time datetime not null,
 end_time datetime,
 primary key(sw_name,userid,start_time),
 foreign key(userid) references users(userid),
 foreign key(sw_name) references software(sw_name)
);


create table request (
 userid varchar(10) not null,
 sw_name varchar(20) not null,
 request_type enum('add','remove'),
 primary key(sw_name,userid),
 foreign key(userid) references users(userid),
 foreign key(sw_name) references software(sw_name)
);

delimiter //
create trigger usage_cleanup after update on users 
for each row
begin
    update sw_usage
    set end_time = now()
    where userid = new.userid;
end;
//
delimiter ;
