insert into software(sw_name,fullpath)
values('Test App 1','CS4430\\TestApp.exe 1'),
      ('Test App 2','CS4430\\TestApp.exe 2'),
      ('Test App 3','CS4430\\TestApp.exe 3'),
      ('Test App 4','CS4430\\TestApp.exe 4'),
      ('Test App 5','CS4430\\TestApp.exe 5'),
      ('Test App 6','CS4430\\TestApp.exe 6'),
      ('Test App 7','CS4430\\TestApp.exe 7'),
      ('Test App 8','CS4430\\TestApp.exe 8'),
      ('Test App 9','CS4430\\TestApp.exe 9'),
      ('Test App 10','CS4430\\TestApp.exe 10'),
      ('Test App 11','CS4430\\TestApp.exe 11'),
      ('Test App 12','CS4430\\TestApp.exe 12'),
      ('Test App 13','CS4430\\TestApp.exe 13'),
      ('Test App 14','CS4430\\TestApp.exe 14'),
      ('Test App 15','CS4430\\TestApp.exe 15'),
      ('Test App 16','CS4430\\TestApp.exe 16'),
      ('Test App 17','CS4430\\TestApp.exe 17'),
      ('Test App 18','CS4430\\TestApp.exe 18'),
      ('Test App 19','CS4430\\TestApp.exe 19'),
      ('Test App 20','CS4430\\TestApp.exe 20');

insert into users(userid,pwd,fname,lname)
values('bcook', '12345', 'Bennett', 'Cook'),    
      ('myouif', '12345', 'Musaab', 'Yousif'),    
      ('shusain', '12345', 'Syed', 'Husian'),
      ('ekdoe', '12345', 'Ernie', 'K-Doe');
 
 
insert into roles(userid,role)
values('bcook','user'),
      ('myouif','admin'),
      ('shusain','user'),
      ('ekdoe','user');

      
insert into department(name,budget)
values('accounting',10000),
      ('manufacturing',100000),
      ('marketing',50000),
      ('it',100);
      
      
insert into works(userid,depart_name)
values('bcook','accounting'),
      ('myouif','it'),
      ('shusain','manufacturing'),
      ('ekdoe','marketing');
      
insert into license(sw_name,depart_name,available,cost_per_user)
values('Test App 1','accounting',10,1),
      ('Test App 2','accounting',10,2),
      ('Test App 3','accounting',10,3),
      ('Test App 4','accounting',10,4),
      ('Test App 5','accounting',10,5),
      ('Test App 4','manufacturing',10,1),
      ('Test App 5','manufacturing',10,2),
      ('Test App 6','manufacturing',10,3),
      ('Test App 7','manufacturing',10,4),
      ('Test App 8','manufacturing',10,5),
      ('Test App 7','marketing',10,5),
      ('Test App 8','marketing',10,5),
      ('Test App 9','marketing',10,5),
      ('Test App 10','marketing',10,5),
      ('Test App 11','marketing',10,5),
      ('Test App 12','marketing',10,5);
