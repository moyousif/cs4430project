﻿using System;
using System.Windows.Forms;

namespace Launcher {
    public partial class LoginDlg : Form {


        public string UserId { set; get; }
        public string Password { set; get; }

        public LoginDlg() {
            InitializeComponent();
        }

        private void _btnLogin_Click(object sender, EventArgs e) {
            UserId = _tbUserId.Text;
            Password = _tbPassword.Text;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void _btnCancel_Click(object sender, EventArgs e) {
            UserId = "";
            Password = "";
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void _tbPassword_KeyDown(object sender, KeyEventArgs e) {
            if(e.KeyCode == Keys.Enter) {
                UserId = _tbUserId.Text;
                Password = _tbPassword.Text;
                this.DialogResult = DialogResult.OK;
                this.Close();
            } // end if 

        }
    }
}
