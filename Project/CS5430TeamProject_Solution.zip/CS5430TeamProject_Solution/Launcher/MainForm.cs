﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.Windows.Forms;

namespace Launcher
{
    public partial class MainForm : Form {
        private DBAccess _dbAccess = new DBAccess();
        private List<string> _requestedSwNames;
        private List<string> _removedSwNames;
        List<SwPackage> _assignedSetOnceAtLogin; // 
        private bool _loggedIn = false;
        private string _desktop;

        public MainForm() {
            InitializeComponent();
            ControlEnable();
            _desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            _requestedSwNames = new List<string>();
            _removedSwNames = new List<string>();
            _assignedSetOnceAtLogin = new List<SwPackage>();
        }

        private void _bntRequest_Click(object sender, EventArgs e) {

            if (_dbAccess.ReadAvailableFromDb() == 0) {

                RequestDlg requestDlg = new RequestDlg();
                requestDlg.SetAvailableSw(_dbAccess.GetAvailable());

                DialogResult result = requestDlg.ShowDialog();
                if (result == DialogResult.OK) {
                    _requestedSwNames = requestDlg.GetRequested();
                } // end if 
            }
            else {
                MessageBox.Show("failed to read available software from DB ");
            } // end if 
        }

        private void _btnRemove_Click(object sender, EventArgs e) {

            if (_dbAccess.ReadAssignedFromDb() == 0) {

                RemoveDlg removeDlg = new RemoveDlg();
                removeDlg.SetAssignedSw(_dbAccess.GetAssigned());

                DialogResult result = removeDlg.ShowDialog();
                if (result == DialogResult.OK) {
                    _removedSwNames = removeDlg.GetRemoved();
                } // end if 
            }
            else {
                MessageBox.Show("failed to read assigned software from DB ");
            } // end if 
        }


        private void _btnLogIn_Click(object sender, EventArgs e) {

            LoginDlg loginDlg = new LoginDlg();
            DialogResult result = loginDlg.ShowDialog();
            if (result == DialogResult.OK) {
                _dbAccess.User = loginDlg.UserId;
                _dbAccess.Password = loginDlg.Password;
            }
            else {
                return;
            } // end if 

            // log in and read assigned sw 
            if (_dbAccess.Login() == 0) {

                _labelUserName.Text = _dbAccess.UserFirst + " " + _dbAccess.UserLast;

                // message box in ReadAssignedFromDb()
                if (_dbAccess.ReadAssignedFromDb() == 0) {

                    _assignedSetOnceAtLogin = _dbAccess.GetAssigned();
                    for (int i = 0; i < _assignedSetOnceAtLogin.Count(); i++) {
                        int row = _dgvAssignedSoftware.Rows.Add();
                        _dgvAssignedSoftware.Rows[row].Cells["_colGridName"].Value =
                                         _assignedSetOnceAtLogin[i].Name;
                        _dgvAssignedSoftware.Rows[row].Tag = i;
                    } // end for 

                    _tmr.Enabled = true;
                    _loggedIn = true;
                } // end if 
            }
            else {
                System.Windows.Forms.MessageBox.Show("invalid user name or password");
            } // end try/catch
            ControlEnable();
        }

        // run a software
        private void _dgvAssignedSoftware_CellContentClick(object sender, DataGridViewCellEventArgs e)  {
            int y = _dgvAssignedSoftware.CurrentCellAddress.Y;

            // ignore the last button 
            if (y + 1 > _assignedSetOnceAtLogin.Count()) return;

            // don't allow a running process to start again
            if (_assignedSetOnceAtLogin[y].ProcessId != 0) return;

            // split the path so the command line args are separate from full path 
            string fullPath = _desktop + "\\" + (_assignedSetOnceAtLogin[y].Fullpath).Trim();
            string exe = ".exe";
            int startAt = fullPath.IndexOf(exe) + exe.Length;

            // test or an ".exe"
            if(startAt == exe.Length) {
                System.Windows.Forms.MessageBox.Show("not a valid executable");
                return;
            }  // end if 

            string args = fullPath.Substring(startAt);
            fullPath = fullPath.Remove(startAt);

            // make sure this does not crash in class
            try {
                Process myProcess = System.Diagnostics.Process.Start(fullPath.Trim(), args.Trim());
                if (myProcess.Id != 0) {
                    _assignedSetOnceAtLogin[y].ProcessName = myProcess.ProcessName;
                    _assignedSetOnceAtLogin[y].ProcessId = myProcess.Id;
                    _assignedSetOnceAtLogin[y].Status = "running";
                    _dgvAssignedSoftware[2, y].Value = _assignedSetOnceAtLogin[y].Status;

                    // add a record to the usage table w/o end time and use sw_name not process name
                    _dbAccess.SetStartUsage(myProcess.Id, _assignedSetOnceAtLogin[y].Name);
                }
                else {
                    _assignedSetOnceAtLogin[y].Status = "failed";
                    _dgvAssignedSoftware[2, y].Value = _assignedSetOnceAtLogin[y].Status;
                } // end if 
            }
            catch (Exception ex) {
                MessageBox.Show(ex.Message);
            } // end try catch
        }


        // make it look professional
        private void ControlEnable() {
            _btnLogIn.Enabled = !_loggedIn;
            _btnRequest.Enabled = _loggedIn;
            _btnRemove.Enabled = _loggedIn;
        } // end ControlEnable


        // check if programs are still running 
        private void _tmr_Tick(object sender, EventArgs e)
        {

            UpdateRunningStatus();

            // add requested sw_names 
            if (_requestedSwNames.Count() > 0) {
                if (_dbAccess.RequestAddRemoveSoftware(_requestedSwNames) == 0) {
                    _requestedSwNames.Clear();
                } // end if 
            } // end if 

            // add requested remove sw_names 
            if (_removedSwNames.Count() > 0) {
                if (_dbAccess.RequestAddRemoveSoftware(_removedSwNames,false) == 0) {
                    _removedSwNames.Clear();
                } // end if 
            } // end if 

        }


        private void UpdateRunningStatus() {
           
            for (int i = 0; i < _assignedSetOnceAtLogin.Count(); i++) {
                string status = "not running";
                if (_assignedSetOnceAtLogin[i].ProcessId != 0) {
                    if (IsProcessRunning(_assignedSetOnceAtLogin[i].ProcessId)) {
                        status = "running";
                    }
                    else {

                        // SetEndUsage will return immediately id process 
                        // id in not in _swRunning;
                        _dbAccess.SetEndUsage(_assignedSetOnceAtLogin[i].ProcessId);

                        _assignedSetOnceAtLogin[i].ProcessId = 0;
                    } // end if 
                } // end if 
                _assignedSetOnceAtLogin[i].Status = status;
                _dgvAssignedSoftware[2, i].Value = _assignedSetOnceAtLogin[i].Status;
            } // end for

            return;
        }

        // check if individual processid is running 
        private bool IsProcessRunning(int id) {
            bool ret = false;
            List<Process> procs = Process.GetProcesses().ToList();
            foreach(Process p in procs) {
                if (p.Id == id) {
                    ret = true;
                    break;
                } // end if 
            } // end for 

            return ret;
        }

    }
}
