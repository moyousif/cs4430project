﻿namespace Launcher
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this._labelUserName = new System.Windows.Forms.Label();
            this._btnRequest = new System.Windows.Forms.Button();
            this._btnRemove = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this._dgvAssignedSoftware = new System.Windows.Forms.DataGridView();
            this._colGridName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._colGridStart = new System.Windows.Forms.DataGridViewButtonColumn();
            this._colGridStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._btnLogIn = new System.Windows.Forms.Button();
            this._tmr = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this._dgvAssignedSoftware)).BeginInit();
            this.SuspendLayout();
            // 
            // _labelUserName
            // 
            this._labelUserName.AutoSize = true;
            this._labelUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this._labelUserName.Location = new System.Drawing.Point(144, 44);
            this._labelUserName.Name = "_labelUserName";
            this._labelUserName.Size = new System.Drawing.Size(0, 29);
            this._labelUserName.TabIndex = 2;
            // 
            // _btnRequest
            // 
            this._btnRequest.Location = new System.Drawing.Point(46, 438);
            this._btnRequest.Name = "_btnRequest";
            this._btnRequest.Size = new System.Drawing.Size(162, 47);
            this._btnRequest.TabIndex = 3;
            this._btnRequest.Text = "Request Additional";
            this._btnRequest.UseVisualStyleBackColor = true;
            this._btnRequest.Click += new System.EventHandler(this._bntRequest_Click);
            // 
            // _btnRemove
            // 
            this._btnRemove.Location = new System.Drawing.Point(255, 438);
            this._btnRemove.Name = "_btnRemove";
            this._btnRemove.Size = new System.Drawing.Size(134, 47);
            this._btnRemove.TabIndex = 4;
            this._btnRemove.Text = "Remove";
            this._btnRemove.UseVisualStyleBackColor = true;
            this._btnRemove.Click += new System.EventHandler(this._btnRemove_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(143, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Assigned Software";
            // 
            // _dgvAssignedSoftware
            // 
            this._dgvAssignedSoftware.AllowUserToDeleteRows = false;
            this._dgvAssignedSoftware.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this._dgvAssignedSoftware.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this._colGridName,
            this._colGridStart,
            this._colGridStatus});
            this._dgvAssignedSoftware.Location = new System.Drawing.Point(46, 118);
            this._dgvAssignedSoftware.Name = "_dgvAssignedSoftware";
            this._dgvAssignedSoftware.ReadOnly = true;
            this._dgvAssignedSoftware.RowHeadersVisible = false;
            this._dgvAssignedSoftware.RowTemplate.Height = 28;
            this._dgvAssignedSoftware.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this._dgvAssignedSoftware.Size = new System.Drawing.Size(548, 300);
            this._dgvAssignedSoftware.TabIndex = 5;
            this._dgvAssignedSoftware.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this._dgvAssignedSoftware_CellContentClick);
            // 
            // _colGridName
            // 
            this._colGridName.HeaderText = "Name";
            this._colGridName.Name = "_colGridName";
            this._colGridName.ReadOnly = true;
            this._colGridName.Width = 225;
            // 
            // _colGridStart
            // 
            this._colGridStart.HeaderText = "Start";
            this._colGridStart.Name = "_colGridStart";
            this._colGridStart.ReadOnly = true;
            this._colGridStart.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this._colGridStart.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this._colGridStart.Width = 50;
            // 
            // _colGridStatus
            // 
            this._colGridStatus.HeaderText = "Status";
            this._colGridStatus.Name = "_colGridStatus";
            this._colGridStatus.ReadOnly = true;
            this._colGridStatus.Width = 70;
            // 
            // _btnLogIn
            // 
            this._btnLogIn.Location = new System.Drawing.Point(46, 37);
            this._btnLogIn.Name = "_btnLogIn";
            this._btnLogIn.Size = new System.Drawing.Size(75, 40);
            this._btnLogIn.TabIndex = 6;
            this._btnLogIn.Text = "login";
            this._btnLogIn.UseVisualStyleBackColor = true;
            this._btnLogIn.Click += new System.EventHandler(this._btnLogIn_Click);
            // 
            // _tmr
            // 
            this._tmr.Interval = 2000;
            this._tmr.Tick += new System.EventHandler(this._tmr_Tick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(644, 534);
            this.Controls.Add(this._btnLogIn);
            this.Controls.Add(this._dgvAssignedSoftware);
            this.Controls.Add(this._btnRemove);
            this.Controls.Add(this._btnRequest);
            this.Controls.Add(this.label2);
            this.Controls.Add(this._labelUserName);
            this.Name = "MainForm";
            this.Text = "Software Launcher";
            ((System.ComponentModel.ISupportInitialize)(this._dgvAssignedSoftware)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label _labelUserName;
        private System.Windows.Forms.Button _btnRequest;
        private System.Windows.Forms.Button _btnRemove;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView _dgvAssignedSoftware;
        private System.Windows.Forms.Button _btnLogIn;
        private System.Windows.Forms.Timer _tmr;
        private System.Windows.Forms.DataGridViewTextBoxColumn _colGridName;
        private System.Windows.Forms.DataGridViewButtonColumn _colGridStart;
        private System.Windows.Forms.DataGridViewTextBoxColumn _colGridStatus;
    }
}

