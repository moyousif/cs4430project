﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Launcher {
    public partial class RemoveDlg : Form {

        private List<SwPackage> _assigned;
        private List<string> _removedSwNames;

        public RemoveDlg() {
            InitializeComponent();
            _assigned = new List<SwPackage>();
            _removedSwNames = new List<string>();

        }

        public void SetAssignedSw(List<SwPackage> assignedSw) {
            _assigned = assignedSw;
            SetGridView();
        } // end SetAssignedSw


        public List<string> GetRemoved() {
            return _removedSwNames;
        } // end GetRequested


        public void SetGridView() {

            for (int i = 0; i < _assigned.Count(); i++) {
                int row = _dgvAssignedSoftware.Rows.Add();
                _dgvAssignedSoftware.Rows[row].Cells["_colGridName"].Value = _assigned[i].Name;
                _dgvAssignedSoftware.Rows[row].Tag = i;
            } // end for 

        } // end SetUpGridView

        private void _btnRemove_Click(object sender, EventArgs e) {

            for (int i = 0; i < _dgvAssignedSoftware.RowCount; i++) {
                if (Convert.ToBoolean(_dgvAssignedSoftware.Rows[i].Cells[1].Value) == true) {
                    string name = _dgvAssignedSoftware.Rows[i].Cells[0].Value.ToString();
                    _removedSwNames.Add(name);
                } // end if  
            } // end for 

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

    }
}
