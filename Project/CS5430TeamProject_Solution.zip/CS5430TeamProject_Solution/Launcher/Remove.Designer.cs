﻿namespace Launcher {
    partial class RemoveDlg {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this._dgvAssignedSoftware = new System.Windows.Forms.DataGridView();
            this._btnRemove = new System.Windows.Forms.Button();
            this._colGridName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._colGridSelect = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this._dgvAssignedSoftware)).BeginInit();
            this.SuspendLayout();
            // 
            // _dgvAssignedSoftware
            // 
            this._dgvAssignedSoftware.AllowUserToDeleteRows = false;
            this._dgvAssignedSoftware.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this._dgvAssignedSoftware.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this._colGridName,
            this._colGridSelect});
            this._dgvAssignedSoftware.Location = new System.Drawing.Point(57, 37);
            this._dgvAssignedSoftware.Name = "_dgvAssignedSoftware";
            this._dgvAssignedSoftware.RowHeadersVisible = false;
            this._dgvAssignedSoftware.RowTemplate.Height = 28;
            this._dgvAssignedSoftware.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this._dgvAssignedSoftware.Size = new System.Drawing.Size(344, 300);
            this._dgvAssignedSoftware.TabIndex = 7;
            // 
            // _btnRemove
            // 
            this._btnRemove.Location = new System.Drawing.Point(230, 359);
            this._btnRemove.Name = "_btnRemove";
            this._btnRemove.Size = new System.Drawing.Size(171, 41);
            this._btnRemove.TabIndex = 8;
            this._btnRemove.Text = "Remove Software";
            this._btnRemove.UseVisualStyleBackColor = true;
            this._btnRemove.Click += new System.EventHandler(this._btnRemove_Click);
            // 
            // _colGridName
            // 
            this._colGridName.HeaderText = "Name";
            this._colGridName.Name = "_colGridName";
            this._colGridName.Width = 140;
            // 
            // _colGridSelect
            // 
            this._colGridSelect.HeaderText = "Select";
            this._colGridSelect.Name = "_colGridSelect";
            this._colGridSelect.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this._colGridSelect.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this._colGridSelect.Width = 65;
            // 
            // RemoveDlg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(483, 449);
            this.Controls.Add(this._btnRemove);
            this.Controls.Add(this._dgvAssignedSoftware);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RemoveDlg";
            this.Text = "Remove Assigned Software";
            ((System.ComponentModel.ISupportInitialize)(this._dgvAssignedSoftware)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView _dgvAssignedSoftware;
        private System.Windows.Forms.Button _btnRemove;
        private System.Windows.Forms.DataGridViewTextBoxColumn _colGridName;
        private System.Windows.Forms.DataGridViewCheckBoxColumn _colGridSelect;
    }
}