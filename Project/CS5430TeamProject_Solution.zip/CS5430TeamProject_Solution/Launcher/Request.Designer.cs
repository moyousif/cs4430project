﻿namespace Launcher {
    partial class RequestDlg {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this._dgvAvailableSoftware = new System.Windows.Forms.DataGridView();
            this._btnRequest = new System.Windows.Forms.Button();
            this._colGridName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._colGridSelect = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this._dgvAvailableSoftware)).BeginInit();
            this.SuspendLayout();
            // 
            // _dgvAvailableSoftware
            // 
            this._dgvAvailableSoftware.AllowUserToDeleteRows = false;
            this._dgvAvailableSoftware.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this._dgvAvailableSoftware.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this._colGridName,
            this._colGridSelect});
            this._dgvAvailableSoftware.Location = new System.Drawing.Point(44, 44);
            this._dgvAvailableSoftware.Name = "_dgvAvailableSoftware";
            this._dgvAvailableSoftware.RowHeadersVisible = false;
            this._dgvAvailableSoftware.RowTemplate.Height = 28;
            this._dgvAvailableSoftware.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this._dgvAvailableSoftware.Size = new System.Drawing.Size(344, 300);
            this._dgvAvailableSoftware.TabIndex = 6;
            // 
            // _btnRequest
            // 
            this._btnRequest.Location = new System.Drawing.Point(217, 361);
            this._btnRequest.Name = "_btnRequest";
            this._btnRequest.Size = new System.Drawing.Size(171, 41);
            this._btnRequest.TabIndex = 7;
            this._btnRequest.Text = "Request Software";
            this._btnRequest.UseVisualStyleBackColor = true;
            this._btnRequest.Click += new System.EventHandler(this._btnRequest_Click);
            // 
            // _colGridName
            // 
            this._colGridName.HeaderText = "Name";
            this._colGridName.Name = "_colGridName";
            this._colGridName.Width = 140;
            // 
            // _colGridSelect
            // 
            this._colGridSelect.HeaderText = "Select";
            this._colGridSelect.Name = "_colGridSelect";
            this._colGridSelect.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this._colGridSelect.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this._colGridSelect.Width = 65;
            // 
            // RequestDlg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(456, 449);
            this.Controls.Add(this._btnRequest);
            this.Controls.Add(this._dgvAvailableSoftware);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RequestDlg";
            this.Text = "Request Software";
            ((System.ComponentModel.ISupportInitialize)(this._dgvAvailableSoftware)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView _dgvAvailableSoftware;
        private System.Windows.Forms.Button _btnRequest;
        private System.Windows.Forms.DataGridViewTextBoxColumn _colGridName;
        private System.Windows.Forms.DataGridViewCheckBoxColumn _colGridSelect;
    }
}