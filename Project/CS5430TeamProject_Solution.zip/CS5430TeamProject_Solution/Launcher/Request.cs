﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Launcher {
    public partial class RequestDlg : Form {

        private List<SwPackage> _available;
        private List<string> _requestedSwNames;

        public RequestDlg() {
            InitializeComponent();
            _available = new List<SwPackage>();
            _requestedSwNames = new List<string>();
        }

        public void SetAvailableSw(List<SwPackage> availableSw) {
            _available = availableSw;
            SetGridView();
        } // end SetAssignedSw

        public List<string> GetRequested() {
            return _requestedSwNames;
        } // end GetRequested

        public void SetGridView() {

            for (int i = 0; i < _available.Count(); i++) {
                int row = _dgvAvailableSoftware.Rows.Add();
                _dgvAvailableSoftware.Rows[row].Cells["_colGridName"].Value = _available[i].Name;
                _dgvAvailableSoftware.Rows[row].Tag = i;
            } // end for 

        } // end SetUpGridView


        private void _btnRequest_Click(object sender, EventArgs e) {

            for (int i = 0; i < _dgvAvailableSoftware.RowCount; i++) {
                if (Convert.ToBoolean(_dgvAvailableSoftware.Rows[i].Cells[1].Value) == true) {
                    string name = _dgvAvailableSoftware.Rows[i].Cells[0].Value.ToString();
                    _requestedSwNames.Add(name);
                } // end if  
            } // end for 

            this.DialogResult = DialogResult.OK;
            this.Close();
        }


    }
}
