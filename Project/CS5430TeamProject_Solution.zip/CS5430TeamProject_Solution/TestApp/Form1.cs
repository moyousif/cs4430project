﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestApp {
    public partial class Form1 : Form {
        public Form1(string[] args) {
            InitializeComponent();

            if (args.Count() > 0) {
                switch (args[0]) {
                    case "1":
                        this.BackColor = Color.FromArgb(0, 255, 255);
                        break;
                    case "2":
                        this.BackColor = Color.FromArgb(222, 184, 135);
                        break;
                    case "3":
                        this.BackColor = Color.FromArgb(95, 158, 160);
                        break;
                    case "4":
                        this.BackColor = Color.FromArgb(255, 127, 80);
                        break;
                    case "5":
                        this.BackColor = Color.FromArgb(255, 140, 0);
                        break;
                    case "6":
                        this.BackColor = Color.FromArgb(255, 215, 0);
                        break;
                    case "7":
                        this.BackColor = Color.FromArgb(165, 42, 42);
                        break;
                    case "8":
                        this.BackColor = Color.FromArgb(128, 128, 0);
                        break;
                    case "9":
                        this.BackColor = Color.FromArgb(255, 99, 71);
                        break;
                    case "10":
                        this.BackColor = Color.FromArgb(255, 0, 255);
                        break;
                    case "11":
                        this.BackColor = Color.FromArgb(222, 184, 0);
                        break;
                    case "12":
                        this.BackColor = Color.FromArgb(95, 100, 190);
                        break;
                    case "13":
                        this.BackColor = Color.FromArgb(80, 127, 255);
                        break;
                    case "14":
                        this.BackColor = Color.FromArgb(0, 255, 140);
                        break;
                    case "15":
                        this.BackColor = Color.FromArgb(215, 45, 100);
                        break;
                    case "16":
                        this.BackColor = Color.FromArgb(42, 42, 165);
                        break;
                    case "17":
                        this.BackColor = Color.FromArgb(0, 128, 0);
                        break;
                    case "18":
                        this.BackColor = Color.FromArgb(0, 99, 150);
                        break;
                    case "19":
                        this.BackColor = Color.FromArgb(128, 128, 128);
                        break;
                    case "20":
                        this.BackColor = Color.FromArgb(45, 99, 255);
                        break;
                    default:
                        break;
                }
                _label.Text = "Test App " + args[0];
            } // end if 

        }
    }
}
